﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;
using AgroControl.OperatorModule.Services;

namespace AgroControl.OperatorModule.Views
{
    public partial class MainWindow : Window
    {
        private AgroControlContext _context;
        private OperatorService _operatorService;
        private ObservableCollection<ПроизводственныеПартии> _batches;

        public MainWindow()
        {
            InitializeComponent();
            _context = App.DbContext ?? new AgroControlContext();
            _operatorService = new OperatorService(_context, App.CurrentUser?.Ид_пользователя ?? 1);
            _batches = new ObservableCollection<ПроизводственныеПартии>();
            lstBatches.ItemsSource = _batches;

            Loaded += async (s, e) => await LoadBatchesAsync();

            lblUser.Text = App.CurrentUser?.ФИО ?? "Аппаратчик";
        }

        private async System.Threading.Tasks.Task LoadBatchesAsync()
        {
            try
            {
                lblStatus.Text = "Загрузка партий...";
                var batches = await _operatorService.GetActiveBatchesAsync();

                _batches.Clear();
                foreach (var batch in batches)
                    _batches.Add(batch);

                lblStatus.Text = $"Загружено: {_batches.Count} активных партий";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                lblStatus.Text = "Ошибка загрузки";
            }
        }

        private async void SelectBatch_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            int batchId = (int)button.Tag;

            var batch = await _operatorService.GetBatchInfoAsync(batchId);

            var executionWindow = new BatchExecutionWindow(batchId);
            executionWindow.Owner = this;
            executionWindow.ShowDialog();

            await LoadBatchesAsync(); // Обновляем список
        }

        private void LstBatches_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Не используется
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null;
            LoginWindow login = new LoginWindow();
            login.Show();
            this.Close();
        }
    }
}
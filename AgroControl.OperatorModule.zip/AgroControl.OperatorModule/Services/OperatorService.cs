﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;

namespace AgroControl.OperatorModule.Services
{
    public class OperatorService
    {
        private readonly AgroControlContext _context;
        private readonly int _currentUserId;

        public OperatorService(AgroControlContext context, int currentUserId)
        {
            _context = context;
            _currentUserId = currentUserId;
        }

        /// <summary>
        /// Получить список активных партий (в работе)
        /// </summary>
        public async Task<List<ПроизводственныеПартии>> GetActiveBatchesAsync()
        {
            return await _context.ПроизводственныеПартии
                .Where(p => p.Статус == "выполняется" || p.Статус == "запланирована")
                .OrderBy(p => p.Время_начала)
                .ToListAsync();
        }

        /// <summary>
        /// Получить все шаги для партии
        /// </summary>
        public async Task<List<ВыполнениеШагов>> GetBatchStepsAsync(int batchId)
        {
            return await _context.ВыполнениеШагов
                .Where(s => s.Ид_партии == batchId)
                .OrderBy(s => s.Номер_шага)
                .ToListAsync();
        }

        /// <summary>
        /// Получить текущий активный шаг
        /// </summary>
        public async Task<ВыполнениеШагов> GetCurrentStepAsync(int batchId)
        {
            return await _context.ВыполнениеШагов
                .FirstOrDefaultAsync(s => s.Ид_партии == batchId &&
                                          s.Время_начала_шага != null &&
                                          s.Время_окончания_шага == null);
        }

        /// <summary>
        /// Начать выполнение шага
        /// </summary>
        public async Task<bool> StartStepAsync(int stepId)
        {
            var step = await _context.ВыполнениеШагов.FindAsync(stepId);
            if (step == null) return false;

            if (step.Время_начала_шага != null)
            {
                throw new Exception("Шаг уже начат!");
            }

            step.Время_начала_шага = DateTime.Now;
            step.Кем_начат = _currentUserId;

            await LogEventAsync(step.Ид_партии, $"Начат шаг: {step.Наименование_шага}");
            await _context.SaveChangesAsync();

            return true;
        }

        /// <summary>
        /// Завершить выполнение шага с фактическими параметрами
        /// </summary>
        public async Task<bool> CompleteStepAsync(int stepId,
            decimal? factTemp, int? factDuration, decimal? factPressure,
            bool hasDeviation, string comment)
        {
            var step = await _context.ВыполнениеШагов.FindAsync(stepId);
            if (step == null) return false;

            if (step.Время_окончания_шага != null)
            {
                throw new Exception("Шаг уже завершён!");
            }

            // Сохраняем фактические значения
            step.Температура_факт_C = factTemp;
            step.Длительность_факт_мин = factDuration;
            step.Давление_факт_бар = factPressure;
            step.Есть_отклонение = hasDeviation;
            step.Комментарий_оператора = comment;
            step.Время_окончания_шага = DateTime.Now;
            step.Кем_завершен = _currentUserId;

            await LogEventAsync(step.Ид_партии,
                $"Завершён шаг: {step.Наименование_шага}. " +
                $"Температура: {factTemp}°C, Давление: {factPressure} бар. " +
                $"Отклонение: {(hasDeviation ? "ДА" : "НЕТ")}");

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> IsAllStepsCompletedAsync(int batchId)
        {
            var steps = await _context.ВыполнениеШагов
                .Where(s => s.Ид_партии == batchId)
                .ToListAsync();

            return steps.All(s => s.Время_окончания_шага != null);
        }

        public async Task CompleteBatchAsync(int batchId)
        {
            var batch = await _context.ПроизводственныеПартии.FindAsync(batchId);
            if (batch == null) return;

            batch.Статус = "завершена";
            batch.Время_окончания = DateTime.Now;
            batch.Кем_завершена = _currentUserId;

            await LogEventAsync(batchId, $"Партия {batch.Номер_партии} полностью завершена");
            await _context.SaveChangesAsync();
        }

        /// <summary>
        /// Получить информацию о партии
        /// </summary>
        public async Task<ПроизводственныеПартии> GetBatchInfoAsync(int batchId)
        {
            return await _context.ПроизводственныеПартии
                .FirstOrDefaultAsync(p => p.Ид_партии == batchId);
        }

        /// <summary>
        /// Логирование событий
        /// </summary>
        private async Task LogEventAsync(int batchId, string text)
        {
            var eventLog = new ЖурналСобытий
            {
                Ид_типа_события = 9, // Тип: Выполнение партии
                Ид_партии = batchId,
                Ид_пользователя = _currentUserId,
                Текст_события = text,
                Дата_создания = DateTime.Now
            };
            _context.ЖурналСобытий.Add(eventLog);
            await _context.SaveChangesAsync();
        }
    }
}
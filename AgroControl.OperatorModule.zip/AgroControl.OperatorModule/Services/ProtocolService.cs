﻿using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;
using System.Data.Entity;

namespace AgroControl.OperatorModule.Services
{
    public class ProtocolService
    {
        private readonly AgroControlContext _context;
        private readonly int _currentUserId;

        public ProtocolService(AgroControlContext context, int currentUserId)
        {
            _context = context;
            _currentUserId = currentUserId;
        }

        /// <summary>
        /// Сформировать протокол выполнения партии
        /// </summary>
        public async Task<string> GenerateExecutionProtocolAsync(int batchId)
        {
            var batch = await _context.ПроизводственныеПартии
                .FirstOrDefaultAsync(p => p.Ид_партии == batchId);

            if (batch == null)
                throw new Exception("Партия не найдена");

            var steps = _context.ВыполнениеШагов
                .Where(s => s.Ид_партии == batchId)
                .OrderBy(s => s.Номер_шага)
                .ToList();

            var protocol = new StringBuilder();
            protocol.AppendLine("<!DOCTYPE html>");
            protocol.AppendLine("<html>");
            protocol.AppendLine("<head>");
            protocol.AppendLine("<meta charset='UTF-8'>");
            protocol.AppendLine($"<title>Протокол выполнения - {batch.Номер_партии}</title>");
            protocol.AppendLine(@"<style>
                body { font-family: 'Segoe UI', Arial, sans-serif; margin: 40px; }
                h1 { text-align: center; color: #2C3E50; }
                .header { text-align: center; margin-bottom: 30px; }
                .info { margin: 20px 0; border: 1px solid #ccc; padding: 15px; background: #F8F9FA; border-radius: 5px; }
                table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
                th { background-color: #3498DB; color: white; }
                .step-completed { background-color: #D4EDDA; }
                .step-deviation { background-color: #F8D7DA; }
                .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #666; }
            </style>");
            protocol.AppendLine("</head>");
            protocol.AppendLine("<body>");

            protocol.AppendLine("<h1>ПРОТОКОЛ ВЫПОЛНЕНИЯ ПРОИЗВОДСТВЕННОЙ ПАРТИИ</h1>");
            protocol.AppendLine($"<div class='header'>{batch.Номер_партии} от {DateTime.Now:dd.MM.yyyy HH:mm}</div>");

            protocol.AppendLine("<div class='info'>");
            protocol.AppendLine($"<p><strong>Номер партии:</strong> {batch.Номер_партии}</p>");
            protocol.AppendLine($"<p><strong>Дата начала:</strong> {batch.Время_начала:dd.MM.yyyy HH:mm}</p>");
            protocol.AppendLine($"<p><strong>Дата окончания:</strong> {batch.Время_окончания:dd.MM.yyyy HH:mm}</p>");
            protocol.AppendLine($"<p><strong>Статус:</strong> {batch.Статус}</p>");
            protocol.AppendLine($"<p><strong>Фактическое количество:</strong> {batch.Факт_количество_кг} кг</p>");
            protocol.AppendLine("</div>");

            protocol.AppendLine("<h3>Последовательность выполнения шагов</h3>");
            protocol.AppendLine("<table>");
            protocol.AppendLine("<tr><th>№</th><th>Наименование шага</th><th>План (T/P/t)</th><th>Факт (T/P/t)</th><th>Отклонение</th></tr>");

            foreach (var step in steps)
            {
                string rowClass = step.Есть_отклонение == true ? "step-deviation" : "step-completed";
                string plan = $"{step.Температура_план_C}°C / {step.Давление_план_бар} бар / {step.Длительность_план_мин} мин";
                string fact = $"{step.Температура_факт_C}°C / {step.Давление_факт_бар} бар / {step.Длительность_факт_мин} мин";
                string deviation = step.Есть_отклонение == true ? "Есть" : "Нет";

                protocol.AppendLine($"<tr class='{rowClass}'>");
                protocol.AppendLine($"<td>{step.Номер_шага}</td>");
                protocol.AppendLine($"<td>{step.Наименование_шага}</td>");
                protocol.AppendLine($"<td>{plan}</td>");
                protocol.AppendLine($"<td>{fact}</td>");
                protocol.AppendLine($"<td>{deviation}</td>");
                protocol.AppendLine("</tr>");

                if (!string.IsNullOrEmpty(step.Комментарий_оператора))
                {
                    protocol.AppendLine($"<tr class='{rowClass}'><td colspan='5' style='background:#FFF3CD'><strong>Комментарий:</strong> {step.Комментарий_оператора}</td></tr>");
                }
            }
            protocol.AppendLine("</table>");

            protocol.AppendLine("<div class='footer'>");
            protocol.AppendLine("<p>Аппаратчик: ___________________ / _______________/</p>");
            protocol.AppendLine("<p>Дата формирования протокола: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm") + "</p>");
            protocol.AppendLine("</div>");

            protocol.AppendLine("</body></html>");

            // Сохраняем протокол
            string fileName = $"Протокол_выполнения_{batch.Номер_партии}_{DateTime.Now:yyyyMMdd_HHmmss}.html";
            string protocolFolder = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Protocols");
            string filePath = Path.Combine(protocolFolder, fileName);

            if (!Directory.Exists(protocolFolder))
                Directory.CreateDirectory(protocolFolder);

            File.WriteAllText(filePath, protocol.ToString(), Encoding.UTF8);

            return filePath;
        }

        /// <summary>
        /// Открыть протокол в браузере
        /// </summary>
        public void OpenProtocol(string filePath)
        {
            if (File.Exists(filePath))
            {
                System.Diagnostics.Process.Start(filePath);
            }
        }
    }
}
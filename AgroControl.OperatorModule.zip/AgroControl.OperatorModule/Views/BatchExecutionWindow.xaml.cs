﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;
using AgroControl.OperatorModule.Services;

namespace AgroControl.OperatorModule.Views
{
    public partial class BatchExecutionWindow : Window
    {
        private readonly int _batchId;
        private AgroControlContext _context;
        private OperatorService _operatorService;
        private ObservableCollection<ВыполнениеШагов> _steps;
        private ВыполнениеШагов _selectedStep;
        private DispatcherTimer _telemetryTimer;
        private DispatcherTimer _stepTimer;
        private DateTime _stepStartTime;

        public BatchExecutionWindow(int batchId)
        {
            InitializeComponent();
            _batchId = batchId;
            _context = App.DbContext ?? new AgroControlContext();
            int userId = App.CurrentUser?.Ид_пользователя ?? 1;
            _operatorService = new OperatorService(_context, userId);
            _steps = new ObservableCollection<ВыполнениеШагов>();
            lstSteps.ItemsSource = _steps;

            _telemetryTimer = new DispatcherTimer();
            _telemetryTimer.Interval = TimeSpan.FromSeconds(2);
            _telemetryTimer.Tick += TelemetryTimer_Tick;

            _stepTimer = new DispatcherTimer();
            _stepTimer.Interval = TimeSpan.FromSeconds(1);
            _stepTimer.Tick += StepTimer_Tick;

            Loaded += async (s, e) => await LoadDataAsync();
            Closed += (s, e) => { _telemetryTimer.Stop(); _stepTimer.Stop(); };
        }

        private async Task LoadDataAsync()
        {
            try
            {
                var batch = await _operatorService.GetBatchInfoAsync(_batchId);
                txtBatchTitle.Text = $"Партия: {batch?.Номер_партии}";
                txtBatchStatus.Text = $"Статус: {batch?.Статус}";

                var steps = await _operatorService.GetBatchStepsAsync(_batchId);
                _steps.Clear();
                foreach (var step in steps)
                    _steps.Add(step);

                UpdateProgress();

                var currentStep = await _operatorService.GetCurrentStepAsync(_batchId);
                if (currentStep != null)
                {
                    txtCurrentStep.Text = $"ТЕКУЩИЙ ШАГ: {currentStep.Наименование_шага}";
                    SelectStep(currentStep);

                    if (currentStep.Время_начала_шага.HasValue)
                    {
                        _stepStartTime = currentStep.Время_начала_шага.Value;
                        _stepTimer.Start();
                    }
                }
                else
                {
                    var firstStep = _steps.FirstOrDefault();
                    if (firstStep != null && firstStep.Время_начала_шага == null)
                    {
                        SelectStep(firstStep);
                    }
                    txtCurrentStep.Text = "Ожидание начала выполнения";
                }

                _telemetryTimer.Start();
                lblStatus.Text = $"Загружено {_steps.Count} шагов | Выполнено: {_steps.Count(s => s.Время_окончания_шага != null)}";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки: {ex.Message}");
            }
        }

        private void UpdateProgress()
        {
            var completedSteps = _steps.Count(s => s.Время_окончания_шага != null);
            int totalSteps = _steps.Count;
            int percent = totalSteps > 0 ? (completedSteps * 100 / totalSteps) : 0;
            txtProgress.Text = percent.ToString();

            if (percent >= 100)
                txtProgress.Foreground = Brushes.Green;
            else if (percent >= 50)
                txtProgress.Foreground = Brushes.Orange;
            else
                txtProgress.Foreground = Brushes.Red;
        }

        private void TelemetryTimer_Tick(object sender, EventArgs e)
        {
            Random rnd = new Random();

            double temp = 0;
            double pressure = 0;
            double speed = 0;

            if (_selectedStep != null && _selectedStep.Время_начала_шага != null && _selectedStep.Время_окончания_шага == null)
            {
                if (_selectedStep.Температура_план_C.HasValue)
                {
                    double planTemp = (double)_selectedStep.Температура_план_C.Value;
                    temp = planTemp + (rnd.NextDouble() - 0.5) * 10;
                    temp = Math.Max(0, temp);
                }
                else
                {
                    temp = rnd.Next(20, 200);
                }

                if (_selectedStep.Давление_план_бар.HasValue)
                {
                    double planPressure = (double)_selectedStep.Давление_план_бар.Value;
                    pressure = planPressure + (rnd.NextDouble() - 0.5) * 2;
                    pressure = Math.Max(0, pressure);
                }
                else
                {
                    pressure = rnd.Next(1, 10);
                }

                speed = rnd.Next(50, 250);
            }
            else
            {
                temp = rnd.Next(20, 50);
                pressure = rnd.Next(0, 3);
                speed = 0;
            }

            txtTelemetryTemp.Text = temp.ToString("F1");
            txtTelemetryPressure.Text = pressure.ToString("F1");
            txtTelemetrySpeed.Text = speed.ToString("F0");

            progressTemp.Value = temp;
            progressPressure.Value = pressure;
            progressSpeed.Value = speed;

            if (_selectedStep != null && _selectedStep.Время_начала_шага != null && _selectedStep.Время_окончания_шага == null)
            {
                bool hasDeviation = false;

                if (_selectedStep.Температура_план_C.HasValue)
                {
                    double planTemp = (double)_selectedStep.Температура_план_C.Value;
                    double tolerance = 5;
                    if (Math.Abs(temp - planTemp) > tolerance)
                    {
                        hasDeviation = true;
                        progressTemp.Background = Brushes.Red;
                    }
                    else
                    {
                        progressTemp.Background = Brushes.Green;
                    }
                }

                if (_selectedStep.Давление_план_бар.HasValue)
                {
                    double planPressure = (double)_selectedStep.Давление_план_бар.Value;
                    double tolerance = 0.5;
                    if (Math.Abs(pressure - planPressure) > tolerance)
                    {
                        hasDeviation = true;
                        progressPressure.Background = Brushes.Red;
                    }
                    else
                    {
                        progressPressure.Background = Brushes.Green;
                    }
                }

                if (hasDeviation && chkDeviation.IsChecked == false)
                {
                    chkDeviation.IsChecked = true;
                    txtComment.Text = $"Автоматически зафиксировано отклонение по телеметрии: T={temp:F1}°C, P={pressure:F1} бар";
                }
            }
        }

        private void StepTimer_Tick(object sender, EventArgs e)
        {
            if (_selectedStep != null && _selectedStep.Время_начала_шага.HasValue && _selectedStep.Время_окончания_шага == null)
            {
                TimeSpan elapsed = DateTime.Now - _stepStartTime;
                txtStepTimer.Text = $"Время выполнения: {elapsed.Minutes:D2}:{elapsed.Seconds:D2}";

                if (_selectedStep.Длительность_план_мин.HasValue && elapsed.TotalMinutes > _selectedStep.Длительность_план_мин.Value)
                {
                    txtStepTimer.Foreground = Brushes.Red;
                    if (chkDeviation.IsChecked == false)
                    {
                        chkDeviation.IsChecked = true;
                        txtComment.Text = $"Превышение плановой длительности на {elapsed.TotalMinutes - _selectedStep.Длительность_план_мин.Value:F0} мин";
                    }
                }
                else
                {
                    txtStepTimer.Foreground = Brushes.White;
                }
            }
        }

        private void SelectStep(ВыполнениеШагов step)
        {
            _selectedStep = step;
            lstSteps.SelectedItem = step;

            txtPlanTemp.Text = step.Температура_план_C?.ToString() + " °C" ?? "Не задана";
            txtPlanPressure.Text = step.Давление_план_бар?.ToString() + " бар" ?? "Не задано";
            txtPlanDuration.Text = step.Длительность_план_мин?.ToString() + " мин" ?? "Не задана";

            txtInstruction.Text = GetInstructionForStep(step.Наименование_шага);

            txtFactTemp.Text = step.Температура_факт_C?.ToString() ?? "";
            txtFactPressure.Text = step.Давление_факт_бар?.ToString() ?? "";
            txtFactDuration.Text = step.Длительность_факт_мин?.ToString() ?? "";
            chkDeviation.IsChecked = step.Есть_отклонение;
            txtComment.Text = step.Комментарий_оператора;

            bool isStarted = step.Время_начала_шага != null;
            bool isCompleted = step.Время_окончания_шага != null;

            btnStartStep.IsEnabled = !isStarted && !isCompleted;
            btnCompleteStep.IsEnabled = isStarted && !isCompleted;

            if (!isCompleted && isStarted)
            {
                _stepStartTime = step.Время_начала_шага.Value;
                _stepTimer.Start();
            }
            else
            {
                _stepTimer.Stop();
                txtStepTimer.Text = "";
            }
        }

        private string GetInstructionForStep(string stepName)
        {
            if (stepName.Contains("Загрузка"))
                return "Убедитесь в наличии всех компонентов. Проверьте весы. Загрузите сырьё согласно рецептуре.";
            if (stepName.Contains("Смешивание"))
                return "Запустите смеситель. Контролируйте температуру и время смешивания.";
            if (stepName.Contains("Экструзия"))
                return "Проверьте настройки экструдера. Контролируйте температуру и давление.";
            if (stepName.Contains("Охлаждение"))
                return "Включите систему охлаждения. Дождитесь достижения целевой температуры.";
            if (stepName.Contains("Фасовка"))
                return "Проверьте весы. Фасуйте продукт согласно спецификации.";
            return "Выполните шаг согласно технологической инструкции.";
        }

        private void LstSteps_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstSteps.SelectedItem is ВыполнениеШагов step)
            {
                SelectStep(step);
            }
        }

        private async void BtnStartStep_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedStep == null) return;

            try
            {
                var result = await _operatorService.StartStepAsync(_selectedStep.Ид_выполнения);
                if (result)
                {
                    await LoadDataAsync();
                    _stepStartTime = DateTime.Now;
                    _stepTimer.Start();
                    MessageBox.Show("Шаг начат!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void BtnCompleteStep_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedStep == null) return;

            try
            {
                decimal? factTemp = null;
                if (!string.IsNullOrWhiteSpace(txtFactTemp.Text))
                    factTemp = decimal.Parse(txtFactTemp.Text);

                int? factDuration = null;
                if (!string.IsNullOrWhiteSpace(txtFactDuration.Text))
                    factDuration = int.Parse(txtFactDuration.Text);

                decimal? factPressure = null;
                if (!string.IsNullOrWhiteSpace(txtFactPressure.Text))
                    factPressure = decimal.Parse(txtFactPressure.Text);

                bool hasDeviation = chkDeviation.IsChecked == true;
                string comment = txtComment.Text;

                var result = await _operatorService.CompleteStepAsync(
                    _selectedStep.Ид_выполнения,
                    factTemp, factDuration, factPressure,
                    hasDeviation, comment);

                if (result)
                {
                    await LoadDataAsync();

                    if (await _operatorService.IsAllStepsCompletedAsync(_batchId))
                    {
                        await _operatorService.CompleteBatchAsync(_batchId);
                        _stepTimer.Stop();
                        MessageBox.Show("Партия успешно завершена!", "Поздравляем!",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Шаг завершён!", "Успех",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void BtnPrintReport_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var protocolService = new ProtocolService(_context, App.CurrentUser?.Ид_пользователя ?? 1);
                string filePath = await protocolService.GenerateExecutionProtocolAsync(_batchId);
                protocolService.OpenProtocol(filePath);
                MessageBox.Show($"Протокол сформирован!\n{filePath}", "Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка формирования протокола: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
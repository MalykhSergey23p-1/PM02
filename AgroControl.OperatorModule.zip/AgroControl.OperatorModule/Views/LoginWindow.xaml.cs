﻿using System;
using System.Linq;
using System.Windows;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;

namespace AgroControl.OperatorModule.Views
{
    public partial class LoginWindow : Window
    {
        private AgroControlContext _context;

        public LoginWindow()
        {
            InitializeComponent();
            _context = App.DbContext ?? new AgroControlContext();
        }

        // ===== ДОБАВИТЬ ЭТОТ МЕТОД =====
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
        // ================================

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            var user = _context.Пользователи
                .FirstOrDefault(u => u.Логин == login && u.Активен == true);

            if (user != null && user.Хэш_пароля == password)
            {
                App.CurrentUser = user;
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
            {
                lblError.Text = "Неверный логин или пароль!";
                lblError.Visibility = Visibility.Visible;
            }
        }
    }
}
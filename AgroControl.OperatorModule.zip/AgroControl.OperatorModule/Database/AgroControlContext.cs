﻿using System.Data.Entity;
using AgroControl.OperatorModule.Entities;

namespace AgroControl.OperatorModule.Database
{
    public class AgroControlContext : DbContext
    {
        public AgroControlContext() : base("Server=KAB17-02\\SQLEXPRESS;Database=AgroControl;Integrated Security=True;")
        {
            Configuration.LazyLoadingEnabled = false;
        }

        // DbSet для всех таблиц
        public DbSet<ВыполнениеШагов> ВыполнениеШагов { get; set; }
        public DbSet<ПроизводственныеПартии> ПроизводственныеПартии { get; set; }
        public DbSet<Пользователи> Пользователи { get; set; }
        public DbSet<Роли> Роли { get; set; }
        public DbSet<ЖурналСобытий> ЖурналСобытий { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ВыполнениеШагов>().ToTable("Выполнение_шагов");
            modelBuilder.Entity<ПроизводственныеПартии>().ToTable("Производственные_партии");
            modelBuilder.Entity<Пользователи>().ToTable("Пользователи");
            modelBuilder.Entity<Роли>().ToTable("Роли");
            modelBuilder.Entity<ЖурналСобытий>().ToTable("Журнал_событий");

            base.OnModelCreating(modelBuilder);
        }
    }
}
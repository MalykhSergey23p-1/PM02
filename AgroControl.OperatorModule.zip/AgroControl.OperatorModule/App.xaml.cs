﻿using System.Windows;
using AgroControl.OperatorModule.Database;
using AgroControl.OperatorModule.Entities;

namespace AgroControl.OperatorModule
{
    public partial class App : Application
    {
        public static AgroControlContext DbContext { get; private set; }
        public static Пользователи CurrentUser { get; set; }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            DbContext = new AgroControlContext();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            DbContext?.Dispose();
            base.OnExit(e);
        }
    }
}
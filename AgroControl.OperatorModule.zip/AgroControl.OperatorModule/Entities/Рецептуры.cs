﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Рецептуры")]
    public class Рецептуры
    {
        [Key]
        public int Ид_рецептуры { get; set; }

        [Required]
        public int Ид_продукта { get; set; }

        public int Версия { get; set; }

        [Required]
        [MaxLength(200)]
        public string Наименование { get; set; }

        [Required]
        [MaxLength(50)]
        public string Статус { get; set; }

        public int Кем_создан { get; set; }

        public DateTime? Дата_создания { get; set; }

        public int? Кем_утвержден { get; set; }

        public DateTime? Дата_утверждения { get; set; }

        public int? Кем_архивирован { get; set; }

        public DateTime? Дата_архивации { get; set; }

        [ForeignKey("Ид_продукта")]
        public virtual Продукция Продукция { get; set; }
    }
}
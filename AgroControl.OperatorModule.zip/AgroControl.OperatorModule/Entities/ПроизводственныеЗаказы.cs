﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Производственные_заказы")]
    public class ПроизводственныеЗаказы
    {
        [Key]
        public int Ид_заказа { get; set; }

        [Required]
        [MaxLength(50)]
        public string Номер_заказа { get; set; }

        [Required]
        public int Ид_рецептуры { get; set; }

        public decimal План_количество_кг { get; set; }

        [Required]
        [MaxLength(50)]
        public string Статус { get; set; }

        public DateTime Плановая_дата_начала { get; set; }

        public int Кем_создан { get; set; }

        public DateTime? Дата_создания { get; set; }

        [ForeignKey("Ид_рецептуры")]
        public virtual Рецептуры Рецептура { get; set; }
    }
}
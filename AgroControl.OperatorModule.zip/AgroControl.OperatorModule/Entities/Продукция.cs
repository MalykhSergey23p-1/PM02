﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Продукция")]
    public class Продукция
    {
        [Key]
        public int Ид_продукта { get; set; }

        [Required]
        [MaxLength(50)]
        public string Код_продукта { get; set; }

        [Required]
        [MaxLength(200)]
        public string Наименование_продукта { get; set; }

        [Required]
        public int Ид_типа_продукции { get; set; }

        [MaxLength(50)]
        public string Форма_выпуска { get; set; }

        [Required]
        [MaxLength(20)]
        public string Статус { get; set; }

        public DateTime? Дата_создания { get; set; }

        public int? Кем_создан { get; set; }

        public DateTime? Дата_обновления { get; set; }

        public int? Кем_обновлен { get; set; }
    }
}
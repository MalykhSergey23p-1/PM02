﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Выполнение_шагов")]
    public class ВыполнениеШагов
    {
        [Key]
        public int Ид_выполнения { get; set; }

        public int Ид_партии { get; set; }
        public int Номер_шага { get; set; }
        public string Наименование_шага { get; set; }

        public decimal? Температура_план_C { get; set; }
        public int? Длительность_план_мин { get; set; }
        public decimal? Давление_план_бар { get; set; }

        public decimal? Температура_факт_C { get; set; }
        public int? Длительность_факт_мин { get; set; }
        public decimal? Давление_факт_бар { get; set; }

        public DateTime? Время_начала_шага { get; set; }
        public DateTime? Время_окончания_шага { get; set; }

        public bool? Есть_отклонение { get; set; }
        public string Комментарий_оператора { get; set; }

        public int? Кем_начат { get; set; }
        public int? Кем_завершен { get; set; }

        [ForeignKey("Ид_партии")]
        public virtual ПроизводственныеПартии Партия { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Производственные_партии")]
    public class ПроизводственныеПартии
    {
        [Key]
        public int Ид_партии { get; set; }

        [Required]
        [MaxLength(50)]
        public string Номер_партии { get; set; }

        [Required]
        public int Ид_заказа { get; set; }

        public DateTime? Время_начала { get; set; }

        public DateTime? Время_окончания { get; set; }

        [Required]
        [MaxLength(50)]
        public string Статус { get; set; }

        public decimal? Факт_количество_кг { get; set; }

        public bool? Есть_отклонения { get; set; }

        public DateTime? Дата_создания { get; set; }

        public int? Кем_запущена { get; set; }

        public int? Кем_завершена { get; set; }

        // Навигационное свойство для связи с заказом
        [ForeignKey("Ид_заказа")]
        public virtual ПроизводственныеЗаказы Заказ { get; set; }

        // Коллекция шагов выполнения
        public virtual ICollection<ВыполнениеШагов> ВыполнениеШагов { get; set; }

        public ПроизводственныеПартии()
        {
            ВыполнениеШагов = new HashSet<ВыполнениеШагов>();
        }
    }
}
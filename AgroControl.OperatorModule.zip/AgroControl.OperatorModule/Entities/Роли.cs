﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Роли")]
    public class Роли
    {
        [Key]
        public int Ид_роли { get; set; }

        [MaxLength(50)]
        public string Наименование_роли { get; set; }
    }
}
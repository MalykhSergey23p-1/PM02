﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Журнал_событий")]
    public class ЖурналСобытий
    {
        [Key]
        public int Ид_события { get; set; }

        public int Ид_типа_события { get; set; }
        public int? Ид_партии { get; set; }
        public int? Ид_пользователя { get; set; }

        public string Текст_события { get; set; }
        public DateTime? Дата_создания { get; set; }
    }
}
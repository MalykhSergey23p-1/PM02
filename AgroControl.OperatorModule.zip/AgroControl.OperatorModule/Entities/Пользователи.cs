﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AgroControl.OperatorModule.Entities
{
    [Table("Пользователи")]
    public class Пользователи
    {
        [Key]
        public int Ид_пользователя { get; set; }

        [MaxLength(50)]
        public string Логин { get; set; }

        [MaxLength(255)]
        public string Хэш_пароля { get; set; }

        [MaxLength(200)]
        public string ФИО { get; set; }

        public int Ид_роли { get; set; }

        public bool? Активен { get; set; }

        [ForeignKey("Ид_роли")]
        public virtual Роли Роль { get; set; }
    }
}
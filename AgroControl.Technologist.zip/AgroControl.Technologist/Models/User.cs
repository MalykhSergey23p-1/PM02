﻿namespace AgroControl.Technologist.Models
{
    public class User
    {
        public int Ид_пользователя { get; set; }
        public string Логин { get; set; }
        public string ФИО { get; set; }
        public string Наименование_роли { get; set; }
        public bool Активен { get; set; }
    }
}
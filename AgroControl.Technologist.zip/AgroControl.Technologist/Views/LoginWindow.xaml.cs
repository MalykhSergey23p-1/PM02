﻿using System;
using System.Windows;
using AgroControl.Technologist.Models;

namespace AgroControl.Technologist.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            btnLogin.Click += BtnLogin_Click;
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                txtStatus.Text = "❌ Введите логин!";
                return;
            }

            if (string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                txtStatus.Text = "❌ Введите пароль!";
                return;
            }

            
            if (txtUsername.Text == "admin" && txtPassword.Password == "admin123")
            {
                txtStatus.Text = "✅ Вход выполнен!";

                var testUser = new User
                {
                    ФИО = "Администратор",
                    Наименование_роли = "Технолог"
                };
                var mainWindow = new MainWindow(testUser);
                mainWindow.Show();
                this.Close();
                return;
            }

            // Если логин/пароль не совпадают
            txtStatus.Text = "❌ Неверный логин или пароль!\nИспользуйте admin / admin123";
        }
    }
}
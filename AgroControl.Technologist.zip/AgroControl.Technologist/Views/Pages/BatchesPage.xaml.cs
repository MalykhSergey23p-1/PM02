﻿using System.Windows.Controls;
using AgroControl.Technologist.Data;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class BatchesPage : Page
    {
        public BatchesPage()
        {
            InitializeComponent();
            this.Loaded += async (s, e) => await LoadData();
            btnRefresh.Click += async (s, e) => await LoadData();
        }

        private async System.Threading.Tasks.Task LoadData()
        {
            string sql = @"SELECT 
                          Ид_партии as 'ID',
                          Номер_партии as 'Номер партии',
                          Статус as 'Статус',
                          Время_начала as 'Время начала',
                          Время_окончания as 'Время окончания',
                          Факт_количество_кг as 'Факт, кг',
                          CASE WHEN Есть_отклонения = 1 THEN 'Есть' ELSE 'Нет' END as 'Отклонения'
                          FROM Производственные_партии 
                          ORDER BY Время_начала DESC";

            var dt = await DatabaseHelper.GetDataTableAsync(sql);
            dgBatches.ItemsSource = dt.DefaultView;
        }
    }
}
﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class TechMapsPage : Page
    {
        public TechMapsPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
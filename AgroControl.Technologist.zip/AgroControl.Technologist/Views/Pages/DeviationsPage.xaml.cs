﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class DeviationsPage : Page
    {
        public DeviationsPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
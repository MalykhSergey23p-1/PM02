﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class QualityPage : Page
    {
        public QualityPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
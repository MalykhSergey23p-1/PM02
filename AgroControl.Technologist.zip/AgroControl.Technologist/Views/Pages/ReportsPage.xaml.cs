﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class ReportsPage : Page
    {
        public ReportsPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
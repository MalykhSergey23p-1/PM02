﻿using System.Windows.Controls;
using AgroControl.Technologist.Data;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class ProductsPage : Page
    {
        public ProductsPage()
        {
            InitializeComponent();
            this.Loaded += async (s, e) => await LoadData();
            btnRefresh.Click += async (s, e) => await LoadData();
        }

        private async System.Threading.Tasks.Task LoadData()
        {
            string sql = @"SELECT 
                          Ид_продукта as 'ID',
                          Код_продукта as 'Код',
                          Наименование_продукта as 'Наименование',
                          Форма_выпуска as 'Форма выпуска',
                          Статус as 'Статус',
                          Дата_создания as 'Дата создания'
                          FROM Продукция 
                          ORDER BY Дата_создания DESC";

            var dt = await DatabaseHelper.GetDataTableAsync(sql);
            dgProducts.ItemsSource = dt.DefaultView;
        }
    }
}
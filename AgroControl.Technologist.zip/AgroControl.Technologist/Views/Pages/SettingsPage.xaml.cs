﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class SettingsPage : Page
    {
        public SettingsPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
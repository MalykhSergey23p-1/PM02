﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
        }

        public void Refresh()
        {
            // Обновление данных
        }
    }
}
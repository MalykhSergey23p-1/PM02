﻿using System.Windows.Controls;
using AgroControl.Technologist.Data;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class RecipesPage : Page
    {
        public RecipesPage()
        {
            InitializeComponent();
            this.Loaded += async (s, e) => await LoadData();
            btnRefresh.Click += async (s, e) => await LoadData();
        }

        private async System.Threading.Tasks.Task LoadData()
        {
            string sql = @"SELECT 
                          р.Ид_рецептуры as 'ID',
                          п.Наименование_продукта as 'Продукт',
                          р.Версия as 'Версия',
                          р.Наименование as 'Наименование рецептуры',
                          р.Статус as 'Статус',
                          р.Дата_создания as 'Дата создания'
                          FROM Рецептуры р
                          JOIN Продукция п ON р.Ид_продукта = п.Ид_продукта
                          ORDER BY р.Дата_создания DESC";

            var dt = await DatabaseHelper.GetDataTableAsync(sql);
            dgRecipes.ItemsSource = dt.DefaultView;
        }
    }
}
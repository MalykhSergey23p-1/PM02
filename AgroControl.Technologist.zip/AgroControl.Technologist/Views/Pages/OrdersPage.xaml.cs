﻿using System.Windows.Controls;

namespace AgroControl.Technologist.Views.Pages
{
    public partial class OrdersPage : Page
    {
        public OrdersPage()
        {
            InitializeComponent();
        }

        public void Refresh() { }
    }
}
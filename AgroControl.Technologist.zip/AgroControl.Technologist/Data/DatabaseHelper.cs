﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace AgroControl.Technologist.Data
{
    public class DatabaseHelper
    {
        private static readonly string _connectionString = "Server=KAB17-02\\SQLEXPRESS;Database=AgroControl;Trusted_Connection=True;MultipleActiveResultSets=true";

        public static async Task<DataTable> GetDataTableAsync(string sql, SqlParameter[] parameters = null)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            using (var adapter = new SqlDataAdapter(cmd))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                var dt = new DataTable();
                await Task.Run(() => adapter.Fill(dt));
                return dt;
            }
        }

        public static async Task<T> GetSingleAsync<T>(string sql, Func<SqlDataReader, T> mapper, SqlParameter[] parameters = null)
        {
            using (var conn = new SqlConnection(_connectionString))
            using (var cmd = new SqlCommand(sql, conn))
            {
                if (parameters != null)
                    cmd.Parameters.AddRange(parameters);

                await conn.OpenAsync();
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    if (await reader.ReadAsync())
                        return mapper(reader);
                    return default(T);
                }
            }
        }
    }
}
﻿using System.Windows;

namespace AgroControl.Technologist
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
           
        }
    }
}
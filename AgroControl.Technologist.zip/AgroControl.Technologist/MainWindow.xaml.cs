﻿using System.Windows;
using AgroControl.Technologist.Models;
using AgroControl.Technologist.Views.Pages;

namespace AgroControl.Technologist
{
    public partial class MainWindow : Window
    {
        public MainWindow(User user)
        {
            InitializeComponent();
            txtUser.Text = $"{user.ФИО}\n{user.Наименование_роли}";

            btnProducts.Click += (s, e) => MainFrame.Navigate(new ProductsPage());
            btnRecipes.Click += (s, e) => MainFrame.Navigate(new RecipesPage());
            btnBatches.Click += (s, e) => MainFrame.Navigate(new BatchesPage());
            btnLogout.Click += (s, e) => { new Views.LoginWindow().Show(); this.Close(); };

            MainFrame.Navigate(new ProductsPage());
        }
    }
}
﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace AgroControl.Technologist.Services
{
    public class CaptchaService
    {
        private static readonly Random _random = new Random();

        public static string GenerateCaptchaText(int length = 6)
        {
            const string chars = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789";
            char[] result = new char[length];
            for (int i = 0; i < length; i++)
            {
                result[i] = chars[_random.Next(chars.Length)];
            }
            return new string(result);
        }

        public static Canvas CreateCaptchaCanvas(string captchaText, int width = 300, int height = 100)
        {
            var canvas = new Canvas
            {
                Width = width,
                Height = height,
                Background = new SolidColorBrush(Colors.White),
                SnapsToDevicePixels = true
            };

            // Очищаем Canvas
            canvas.Children.Clear();

            // Шумовые точки
            for (int i = 0; i < 200; i++)
            {
                var point = new Ellipse
                {
                    Width = 2,
                    Height = 2,
                    Fill = new SolidColorBrush(Color.FromRgb(
                        (byte)_random.Next(100, 200),
                        (byte)_random.Next(100, 200),
                        (byte)_random.Next(100, 200)))
                };
                Canvas.SetLeft(point, _random.Next(0, width));
                Canvas.SetTop(point, _random.Next(0, height));
                canvas.Children.Add(point);
            }

            // Линии помех
            for (int i = 0; i < 10; i++)
            {
                var line = new Line
                {
                    X1 = _random.Next(0, width),
                    Y1 = _random.Next(0, height),
                    X2 = _random.Next(0, width),
                    Y2 = _random.Next(0, height),
                    Stroke = new SolidColorBrush(Color.FromRgb(
                        (byte)_random.Next(100, 180),
                        (byte)_random.Next(100, 180),
                        (byte)_random.Next(100, 180))),
                    StrokeThickness = 1
                };
                canvas.Children.Add(line);
            }

            // Текст CAPTCHA
            string[] fonts = { "Arial", "Verdana", "Times New Roman" };
            for (int i = 0; i < captchaText.Length; i++)
            {
                var text = new TextBlock
                {
                    Text = captchaText[i].ToString(),
                    FontSize = _random.Next(28, 48),
                    FontFamily = new FontFamily(fonts[_random.Next(fonts.Length)]),
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(Color.FromRgb(
                        (byte)_random.Next(20, 140),
                        (byte)_random.Next(20, 140),
                        (byte)_random.Next(20, 140)))
                };

                double x = 15 + (i * (width / captchaText.Length)) + _random.Next(-5, 15);
                double y = _random.Next(20, 65);
                Canvas.SetLeft(text, x);
                Canvas.SetTop(text, y);
                text.RenderTransform = new RotateTransform(_random.Next(-25, 25));
                canvas.Children.Add(text);
            }

            return canvas;
        }
    }
}